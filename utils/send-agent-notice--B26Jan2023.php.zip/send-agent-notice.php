<?php
// $agent = false;
// require_once "../../lib/PHPMailer/PHPMailerAutoload.php";
require_once "../lib/PHPMailer/PHPMailerAutoload.php";
// $agent = unserialize(base64_decode($_REQUEST['agent']));
// if(!isset($_REQUEST['debug'])) {
//     if(isset($_REQUEST['agent'] )) {
//       if(isset($agent) && !empty($agent)){
//         if(isset($agent['name']) && !is_null($agent['name']) && !empty($agent['name'])){
//
//         }
//       }
//         // $agent = unserialize(base64_decode($_REQUEST['agent']));
//     }
// } else {
//     //error_log("NOT Sending Notice");
// }

if(isProperAgentURL($agent)){
  sendNotice($agent);
}
function sendNotice($agent) {
    error_log("Sending Notice");
    // $actual_link = $_SERVER['HTTP_REFERER'];
    $actual_link = $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
    $nl = "\r\n";

    //PHPMailer Object
    $mail = new PHPMailer;
    $mail->isSMTP();
    // $mail->SMTPDebug = 2;
    $mail->Debugoutput = 'html';
    $mail->Host = "kr5l-d26p.accessdomain.com";
    $mail->Port = 587;
    //Whether to use SMTP authentication
    $mail->SMTPAuth = true;
    $mail->Username = "purl@onlyinsuranceleads.com";
    $mail->Password = "9ny3mNXnDbHxhs@";

    //From email address and name
    // $mail->From = "service@OnlyInsuranceLeads.com";
    $mail->From = "info@OnlyInsuranceLeads.com";

    $mail->FromName = "OnlyInsuranceLeads";

    // To address and name
    // $mail->addAddress('seth@OnlyInsuranceLeads.com', 'Only Insurance Leads');

    $mail->addAddress('david@OnlyInsuranceLeads.com', 'David Cohen');
    $mail->addAddress('service@OnlyInsuranceLeads.com', 'Only Insurance Leads');
    $mail->addAddress('stephanie@onlyinsuranceleads.com', 'Stephanie');

    // $mail->addAddress('kkambeya@designsnsuch.com', 'Kalanda Kambeya');
    // $mail->addAddress('hafiz.bilalahmadgondal@gmail.com', 'Bilal Ahmad');


    if(isset($agent['salesperson_email'])){
        $mail->addAddress($agent['salesperson_email']);
    }

    //Address to which recipient will reply
    $mail->addReplyTo("service@OnlyInsuranceLeads.com", "Reply");

    //Send HTML or Plain Text email
    $mail->isHTML(false);

    $mail->Subject = 'OnlyInsuranceLeads PURL '.$agent['name'];
    $message = '';
    $message .= 'An agent has hit their personal URL!'.$nl.$nl;
    $message .= 'When: '.date("m/d/Y").' at '.date("h:i A").$nl;
    $message .= 'Name: '.$agent['name'].$nl;
    $message .= 'Phone: '.$agent['phone'].$nl;
    $message .= 'Email: '.$agent['email'].$nl;
    $message .= 'PURL: '.$agent['purl'].$nl;
    $message .= 'URL: '.$actual_link.$nl;
    $message .= 'PURL Hits: '.($agent['hits'] + 1).$nl;

    //TODO have to remove , testing debug die
    // $message .= 'Request parameters are : '.$nl;
    // foreach ($_REQUEST as $key => $value) {
    //   $message .= 'Key: '.$key.$nl;
    //   $message .= 'Value: '.$value.$nl;
    // }
    // $message .= 'Server parameters are : '.$nl;
    // foreach ($_SERVER as $key => $value) {
    //     $message .= 'Key: '.$key.$nl;
    //     $message .= 'Value: '.$value.$nl;
    // }
    //END

    $message .= $agent['hitDates'];
    $message = wordwrap($message, 70, $nl);

    $mail->Body = $message;
    if(!$mail->send())
    {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
    else
    {
        // echo "Message has been sent successfully ";
    }
}
?>
